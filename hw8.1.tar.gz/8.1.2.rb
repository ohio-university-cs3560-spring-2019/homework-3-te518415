#!/usr/bin/ruby

if (gets =~ /^[a-z]{2}[0-9]{6}+@ohio.edu$/)
	puts "True"
else
	puts "False"
end
