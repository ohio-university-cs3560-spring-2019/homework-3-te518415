#!/usr/bin/ruby

if (gets =~ /^[A-z_]+[A-z_0-9]+$/)
	puts "True"
else
	puts "False"
end

